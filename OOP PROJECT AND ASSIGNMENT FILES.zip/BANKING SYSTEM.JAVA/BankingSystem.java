import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

class BankAccount {
    private final int accountNumber;
    private final String name;
    private final String phoneNumber;
    private double balance;
    private final String bankName = "COMMERICIAL BANK OF ETHIOPIA";

    public BankAccount(int accountNumber, String name, String phoneNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.balance = initialBalance;
    }

    public boolean deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            return true;
        }
        return false;
    }

    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }

    public double getBalance() {
        return balance;
    }

    public void displayAccountInfo() {
        System.out.println("\nAccount Information for " + bankName);
        System.out.println("=".repeat(40));
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Holder: " + name);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.printf("Current Balance: $%.2f\n", balance);
        System.out.println("=".repeat(40));
    }

    public int getAccountNumber() {
        return accountNumber;
    }
}

public class BankingSystem {
    private final HashMap<Integer, BankAccount> accounts;
    private int nextAccountNumber;
    private final Scanner scanner;

    public BankingSystem() {
        accounts = new HashMap<>();
        nextAccountNumber = 1000; // Starting account number
        scanner = new Scanner(System.in);
    }

    public void createAccount() {
        System.out.println("\nCreate New Account with COMMERICIAL BANK OF ETHIOPIA");
        System.out.println("=".repeat(40));
        
        System.out.print("Enter full name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter phone number: ");
        String phoneNumber = scanner.nextLine();
        
        double initialDeposit = 0;
        while (true) {
            try {
                System.out.print("Enter initial deposit amount: $");
                initialDeposit = scanner.nextDouble();
                scanner.nextLine(); // Consume newline
                if (initialDeposit <= 0) {
                    System.out.println("Initial deposit must be positive.");
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Clear invalid input
            }
        }

        int accountNumber = nextAccountNumber++;
        BankAccount newAccount = new BankAccount(accountNumber, name, phoneNumber, initialDeposit);
        accounts.put(accountNumber, newAccount);

        System.out.println("\nAccount created successfully!");
        System.out.println("Your COMMERICIAL BANK OF ETHIOPIA account number is: " + accountNumber);
    }

    public void depositMoney() {
        try {
            System.out.print("\nEnter your COMMERICIAL BANK OF ETHIOPIA Bank account number: ");
            int accountNumber = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (accounts.containsKey(accountNumber)) {
                System.out.print("Enter deposit amount: $");
                double amount = scanner.nextDouble();
                scanner.nextLine(); // Consume newline

                if (accounts.get(accountNumber).deposit(amount)) {
                    System.out.printf("\n$%.2f deposited successfully!\n", amount);
                    System.out.printf("New balance: $%.2f\n", accounts.get(accountNumber).getBalance());
                } else {
                    System.out.println("Invalid deposit amount. Please enter a positive value.");
                }
            } else {
                System.out.println("Account not found. Please check your account number.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter numbers only.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    public void withdrawMoney() {
        try {
            System.out.print("\nEnter your COMMERICIAL BANK OF ETHIOPIA Bank account number: ");
            int accountNumber = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (accounts.containsKey(accountNumber)) {
                System.out.print("Enter withdrawal amount: $");
                double amount = scanner.nextDouble();
                scanner.nextLine(); // Consume newline

                if (accounts.get(accountNumber).withdraw(amount)) {
                    System.out.printf("\n$%.2f withdrawn successfully!\n", amount);
                    System.out.printf("Remaining balance: $%.2f\n", accounts.get(accountNumber).getBalance());
                } else {
                    System.out.println("Invalid withdrawal amount or insufficient funds.");
                }
            } else {
                System.out.println("Account not found. Please check your account number.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter numbers only.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    public void viewBalance() {
        try {
            System.out.print("\nEnter your COMMERICIAL BANK OF ETHIOPIA Bank account number: ");
            int accountNumber = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (accounts.containsKey(accountNumber)) {
                accounts.get(accountNumber).displayAccountInfo();
            } else {
                System.out.println("Account not found. Please check your account number.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter numbers only.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    public void run() {
        while (true) {
            System.out.println("\nCOMMERICIAL BANK OF ETHIOPIA - MAIN MENU");
            System.out.println("=".repeat(40));
            System.out.println("1. Create New Account");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. View Account Balance");
            System.out.println("5. Exit");
            System.out.println("=".repeat(40));

            System.out.print("Enter your choice (1-5): ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> createAccount();
                case "2" -> depositMoney();
                case "3" -> withdrawMoney();
                case "4" -> viewBalance();
                case "5" -> {
                    try (scanner) {
                        System.out.println("\nThank you for banking with COMMERICIAL BANK OF ETHIOPIA Bank!");
                    }
                    return;
                }

                default -> System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }

    public static void main(String[] args) {
        BankingSystem bank = new BankingSystem();
        bank.run();
    }
}